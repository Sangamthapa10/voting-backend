from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import CategoryViewSet, CandidateViewSet, VoteViewSet, ElectionResultViewSet, BlockchainViewSet

router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'candidates', CandidateViewSet)
router.register(r'votes', VoteViewSet, basename="votes")
router.register(r'results', ElectionResultViewSet, basename="results")
router.register(r'blockchain', BlockchainViewSet, basename="blockchain")

urlpatterns = [
    path('', include(router.urls)),
]
