from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.authentication import TokenAuthentication

from .models import Category, Candidate, Vote, ElectionResult, VoteBlock
from .serializers import (
    CategorySerializer, CandidateSerializer,
    VoteSerializer, ElectionResultSerializer, VoteBlockSerializer
)
from blockchain import VoteBlockchain


# CATEGORY APIs
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]


# CANDIDATE APIs
class CandidateViewSet(viewsets.ModelViewSet):
    queryset = Candidate.objects.all()
    serializer_class = CandidateSerializer
    permission_classes = [AllowAny]


# VOTE APIs
class VoteViewSet(viewsets.ModelViewSet):
    serializer_class = VoteSerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Vote.objects.filter(voter=self.request.user)

    def create(self, request):
        candidate_id = request.data.get("candidate")

        if not candidate_id:
            return Response({"error": "candidate is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            candidate = Candidate.objects.get(id=candidate_id)
        except Candidate.DoesNotExist:
            return Response({"error": "Candidate not found"}, status=status.HTTP_404_NOT_FOUND)

        # Check: one vote per category per user
        category = candidate.category
        already_voted = Vote.objects.filter(
            voter=request.user,
            candidate__category=category
        ).exists()

        if already_voted:
            return Response(
                {"error": f"You have already voted in the '{category.name}' category."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Record the vote on the blockchain
        vote_data = {
            "voter_id": request.user.id,
            "voter_username": request.user.username,
            "candidate_id": candidate.id,
            "candidate_name": candidate.name,
            "category_id": category.id,
            "category_name": category.name,
        }
        block = VoteBlockchain.add_vote_block(vote_data)

        # Save vote to DB
        vote = Vote.objects.create(
            candidate=candidate,
            voter=request.user,
            block_hash=block["hash"]
        )

        # Update ElectionResult tally
        result, created = ElectionResult.objects.get_or_create(
            candidate=candidate,
            category=category,
            defaults={"vote_count": 1}
        )
        if not created:
            result.vote_count += 1
            result.save()

        return Response({
            "status": "vote_cast",
            "candidate": candidate.name,
            "category": category.name,
            "block_hash": block["hash"],
            "block_index": block["index"],
        }, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'], url_path='check/(?P<category_id>[^/.]+)')
    def check_voted(self, request, category_id=None):
        """Check if the current user has already voted in a given category."""
        voted = Vote.objects.filter(
            voter=request.user,
            candidate__category_id=category_id
        ).exists()
        return Response({"voted": voted})


# ELECTION RESULTS APIs
class ElectionResultViewSet(viewsets.ViewSet):
    permission_classes = [AllowAny]

    def list(self, request):
        results = ElectionResult.objects.all()
        serializer = ElectionResultSerializer(results, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='category/(?P<category_id>[^/.]+)')
    def category_results(self, request, category_id=None):
        results = ElectionResult.objects.filter(category_id=category_id)
        serializer = ElectionResultSerializer(results, many=True)
        return Response(serializer.data)


# BLOCKCHAIN AUDIT APIs
class BlockchainViewSet(viewsets.ViewSet):
    permission_classes = [AllowAny]

    def list(self, request):
        """Return all blocks in the chain."""
        blocks = VoteBlock.objects.order_by('index')
        serializer = VoteBlockSerializer(blocks, many=True)
        return Response({
            "chain_valid": VoteBlockchain.is_chain_valid(),
            "block_count": blocks.count(),
            "blocks": serializer.data,
        })

    @action(detail=False, methods=['get'], url_path='verify')
    def verify(self, request):
        """Simple endpoint to verify chain integrity."""
        valid = VoteBlockchain.is_chain_valid()
        return Response({
            "chain_valid": valid,
            "message": "Blockchain integrity verified." if valid else "WARNING: Chain tampered!"
        })
